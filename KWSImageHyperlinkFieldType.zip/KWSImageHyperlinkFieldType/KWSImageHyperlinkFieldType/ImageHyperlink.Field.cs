﻿using System;
using System.Globalization;
using System.IO;
using System.Net;
using System.Security.Permissions;
using System.Windows.Controls;
using KWS.SharePoint.WebControls;
using KWS.System.Windows.Controls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using Microsoft.SharePoint.WebControls;

namespace KWS.Sharepoint.ImageHyperlinkFieldType
{
    public class ImageHyperlinkField : SPFieldUrl
    {
        public ImageHyperlinkField(SPFieldCollection fields, string fieldName)
            : base(fields, fieldName)
        {
            base.DisplayFormat = SPUrlFieldFormatType.Hyperlink;
        }

        public ImageHyperlinkField(SPFieldCollection fields, string typeName, string displayName)
            : base(fields, typeName, displayName)
        {
            base.DisplayFormat = SPUrlFieldFormatType.Hyperlink;
        }

        public string UrlFieldHref { get; set; }

        public override BaseFieldControl FieldRenderingControl
        {
            [SharePointPermission(SecurityAction.LinkDemand, ObjectModel = true)]
            get
            {
                BaseFieldControl fieldControl = new ImageHyperlinkFieldControl();
                fieldControl.FieldName = this.InternalName;
                return fieldControl;
            }
        }

        //private string MakeTinyUrl(string Url)
        //{
        //    return "http://www.baidu.com";
        //} 

        private string MakeTinyUrl(string Url)
        {
            try
            {
                if (Url.Length <= 30)
                {
                    return Url;
                }
                if (!Url.ToLower().StartsWith("http") && !Url.ToLower().StartsWith("ftp"))
                {
                    Url = "http://" + Url;
                }
                var request = WebRequest.Create("http://tinyurl.com/api-create.php?url=" + Url);
                var res = request.GetResponse();
                string text;
                using (var reader = new StreamReader(res.GetResponseStream()))
                {
                    text = reader.ReadToEnd();
                }
                return text;
            }
            catch (Exception)
            {
                return Url;
            }
        } 

        public override string GetValidatedString(object value)
        {
            if ((this.Required == true) && ((value == null) || ((String)value == "")))
            {
                throw new SPFieldValidationException(this.Title + " must have a value.");
            }
            else
            {
                ImageHyperlinkValidationRule rule = new ImageHyperlinkValidationRule();
                ValidationResult result = rule.Validate(value, CultureInfo.InvariantCulture);

                if (!result.IsValid)
                {
                    throw new SPFieldValidationException((String)result.ErrorContent);
                }
                else
                {
                    char[] delimiterChar = { ','};
                    string[] urlValues = value.ToString().Split(delimiterChar);
                    if (urlValues[0].StartsWith("http") || urlValues[0].StartsWith("ftp"))
                    {
                        // Shorten the URL
                        urlValues[0] = MakeTinyUrl(urlValues[0]);
                    }
                    value = urlValues[0] + "," + urlValues[1];

                    return base.GetValidatedString(value);
                }
            }
        }

    }
}
