﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Runtime.InteropServices;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using KWS.Sharepoint.ImageHyperlinkFieldType;
using System.Net;
using System.IO;

namespace KWS.SharePoint.WebControls
{
    class ImageHyperlinkFieldControl : UrlField
    {
        protected HyperLink hlUrlField;
        //protected Label labNoteField;

        protected override string DefaultTemplateName
        {
            get
            {
                if (this.ControlMode == SPControlMode.Display)
                {
                    return this.DisplayTemplateName;
                }
                else
                {
                    return "ImageHyperlinkFieldControl";
                }
            }
        }

        public override string DisplayTemplateName
        {
            get
            {
                return "ImageHyperlinkFieldControlForDisplay";
            }
            set
            {
                base.DisplayTemplateName = value;
            }
        }

        private string MakeHugeUrl(string Url)
        {
            return "http://012345678911234567892123456789312345678941234567895123456789612345678971234567898123456789912345678901234567891123456789212345678931234567894123456789512345678961234567897123456789812345611191234567890123456789112345678921234567893123456789412.asp?a=012345678911234567892123456789312345678941234567895123456789612345678971234567898123456789912345678901234567891123456789212345678931234567894123456789512345678961234567897123456789812345678991234567890123456789112345678921234567893123456789412345678951234567896123456789712345678981234567899123456789012345678911234567892123456789312345678941234567895123456789612345678971234567898123456789912345678901234567891123456789212345678931234567894123456789512345678961234567897123456789812345678991234567890123456789112345678921234567893123456789412345678951234567896123456789712345678981234567899123456789012345678911234567892123456789312345678941234567895123456789612345678971234567898123456789912345678901234567891123456789212345678931234567894123456789512345678961234567890123456789112345678921234567893123456789412345678951234567896123456789712345678981234567899123456789012345678911234567892123456789312345678941234567895123456789612345678971234567898123456789912345678967897123456789812345678991234567890123456789112345678921234567893123456789412345678951234567896123456789712345678981234567899123456789012345678911234567892123456789312345678941234567895123456789612345678971234567898123456789912345678967897123456789812345678991234567890123456789112345678921234567893123456789412345678951234567896123456789712345678981234567899123456789012345678911234567892123456789312345678941234567895123456789612345678971234567898123456789912345678967897123456789812345678991234567890123456789112345678921234567893123456789412345678951234567896123456789712345678981234567899123456789012345678911234567892123456789312345678941234567895123456789612345678971234567898123456789912345678967897123456789812345678991234567890124567891123456789212345678931&b=234567894123456789512344567893123456789111111111111";
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            // Lengthen the URL
            switch (this.ControlMode)
            {
                case SPControlMode.Display:
                    //this.hlUrlField.ImageUrl = ((SPFieldUrlValue)this.ItemFieldValue).Description;
                    this.hlUrlField.Text = ((SPFieldUrlValue)this.ItemFieldValue).Description;
                    this.hlUrlField.NavigateUrl = MakeHugeUrl(((SPFieldUrlValue)this.ItemFieldValue).Url);
                    break;
                case SPControlMode.Edit:
                    this.textBox.Text = ((SPFieldUrlValue)this.ItemFieldValue).Description;
                    this.urlBox.Text = MakeHugeUrl(((SPFieldUrlValue)this.ItemFieldValue).Url);
                    break;
                case SPControlMode.Invalid:
                    break;
                case SPControlMode.New:
                    break;
                default:
                    break;
            }
        }

        protected override void CreateChildControls()
        {
            if (this.Field != null)
            {
                // Make sure inherited child controls are completely rendered.
                base.CreateChildControls();

                // Associate child controls in the .ascx file with the fields allocated by this control.
                this.textBox = (TextBox)TemplateContainer.FindControl("UrlFieldDescription");
                this.urlBox = (TextBox)TemplateContainer.FindControl("UrlFieldUrl");
                this.hlUrlField = (HyperLink)TemplateContainer.FindControl("hlUrlField");

                switch (this.ControlMode)
                {
                    case SPControlMode.New:
                        if (!Page.IsPostBack) this.textBox.Text = string.Empty;
                        break;
                    case SPControlMode.Display:
                        //this.hlUrlField.ImageUrl = ((SPFieldUrlValue)this.ItemFieldValue).Description;
                        this.hlUrlField.Text = ((SPFieldUrlValue)this.ItemFieldValue).Description;
                        this.hlUrlField.NavigateUrl = ((SPFieldUrlValue)this.ItemFieldValue).Url;
                        break;
                    case SPControlMode.Edit:
                        this.textBox.Text = ((SPFieldUrlValue)this.ItemFieldValue).Description;
                        this.urlBox.Text = ((SPFieldUrlValue)this.ItemFieldValue).Url;
                        break;
                }
            }
        }

        public override object Value
        {
            get
            {
                EnsureChildControls();
                return base.Value;
            }
            set
            {
                EnsureChildControls();
                base.Value = (SPFieldUrlValue)value;
            }
        }
    }
}

